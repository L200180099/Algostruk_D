class Queue(object):
    def __init__(self):
        self.qlist=[]

    def isEmpty(self):
        return len(self) ==0
    def __len__(self):
        return len(self.qlist)
    def enqueue(self,data):
        self.qlist.append(data)
    def dequeue(self):
        assert not self.isEmpty()
        return self.qlist.pop(0)
    def getFrontMost(self):
        return self.qlist.pop(0)
    def getRearMost(self):
        return self.qlist.pop(-1)

A = Queue()
A.enqueue("Nayu")
A.enqueue("Berlin")
A.enqueue("Wulan")
A.enqueue("Elsa")
A.enqueue("Ayud")
A.enqueue("Irul")

front = A.getFrontMost()
rear = A.getRearMost()
print ("Nilai paling depan = ", front)
print ("Nilai paling belakang = ", rear)
