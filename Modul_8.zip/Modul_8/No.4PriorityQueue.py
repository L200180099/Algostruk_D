import heapq
class PriorityQueue(object):
    def __init__(self):
        self.qlist= []
    def __len__(self):
        return len(self.qlist)
    def isEmpty(self):
        return len(self)==0
    def enqueue(self, data, prior):
        heapq.heappush(self.qlist, (prior, data))
        self.qlist.sort()
    def dequeue(self):
        return self.qlist.pop(-1)
    def getFrontMost(self):
        return self.qlist[-1]
    def getRearMost(self):
        return self.qlist[0]
    
A = PriorityQueue()
A.enqueue("Nayu",6)
A.enqueue("Ayud",8)
A.enqueue("Wulan",4)
A.enqueue("Irul",10)
A.enqueue("Chandika",9)
print(A.getFrontMost())
print(A.getRearMost())
